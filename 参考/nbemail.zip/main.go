package main

import (
	"embed"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	"nbemail/internal/config"
	"nbemail/internal/database"
	"nbemail/internal/server"
	"nbemail/internal/smtp"
)

//go:embed web/static
var staticFiles embed.FS

//go:embed web/templates
var templateFiles embed.FS

func main() {
	var port = flag.Int("port", 8080, "Web服务端口")
	var smtpPort = flag.Int("smtp-port", 2525, "SMTP服务端口")
	var dbPath = flag.String("db", "nbemail.db", "数据库文件路径")
	flag.Parse()

	// 加载配置
	cfg := config.GetDefaults()

	// 显示外部SMTP配置状态
	if cfg.OutboundSMTPHost != "" {
		log.Printf("外部SMTP配置已加载 - Host: %s, Port: %d, User: %s, TLS: %v",
			cfg.OutboundSMTPHost, cfg.OutboundSMTPPort, cfg.OutboundSMTPUser, cfg.OutboundSMTPTLS)
	} else {
		log.Printf("外部SMTP未配置，只能在本地用户间发送邮件")
	}

	// 覆盖命令行参数
	if *port != 8080 {
		cfg.WebPort = *port
	}
	if *smtpPort != 2525 {
		cfg.SMTPPort = *smtpPort
	}
	if *dbPath != "nbemail.db" {
		cfg.DBPath = *dbPath
	}

	// 初始化数据库
	db, err := database.Init(cfg.DBPath)
	if err != nil {
		log.Fatalf("数据库初始化失败: %v", err)
	}
	defer db.Close()

	// 启动SMTP服务器
	smtpServer := smtp.NewServer(cfg, db)
	go func() {
		log.Printf("启动SMTP服务器，端口: %d", cfg.SMTPPort)
		if err := smtpServer.Start(); err != nil {
			log.Fatalf("SMTP服务器启动失败: %v", err)
		}
	}()

	// 启动Web服务器
	webServer := server.NewServer(cfg, db, staticFiles, templateFiles)
	go func() {
		log.Printf("启动Web服务器，端口: %d", cfg.WebPort)
		if err := webServer.Start(); err != nil {
			log.Fatalf("Web服务器启动失败: %v", err)
		}
	}()

	// 等待信号
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	<-c

	fmt.Println("\n正在关闭NBEmail服务器...")
	smtpServer.Stop()
	webServer.Stop()
	fmt.Println("NBEmail服务器已关闭")
}