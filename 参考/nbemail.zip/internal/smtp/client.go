package smtp

import (
	"encoding/base64"
	"crypto/tls"
	"fmt"
	"log"
	"net/smtp"
	"strings"

	"nbemail/internal/config"
)

// OutboundClient 外部SMTP客户端
type OutboundClient struct {
	config *config.Config
}

// NewOutboundClient 创建外部SMTP客户端
func NewOutboundClient(cfg *config.Config) *OutboundClient {
	return &OutboundClient{
		config: cfg,
	}
}

// SendEmail 发送邮件到外部邮箱
func (c *OutboundClient) SendEmail(from, to, subject, body string) error {
	// 根据发件人邮箱获取对应的SMTP配置
	smtpConfig := c.config.GetSMTPConfigForEmail(from)
	if smtpConfig == nil {
		return fmt.Errorf("未找到发件人 %s 对应的SMTP配置", from)
	}

	// 确定实际发件人地址
	actualFrom := from
	if smtpConfig.User != "" {
		// 对于第三方SMTP服务器，使用认证用户作为发件人
		actualFrom = smtpConfig.User
	}

	// 构建邮件内容，在邮件头中保留原始发件人，但在Reply-To中设置
	message := c.buildMessage(actualFrom, to, subject, body, from)

	// 设置认证（如果配置了用户名和密码）
	var auth smtp.Auth
	if smtpConfig.User != "" && smtpConfig.Password != "" {
		auth = smtp.PlainAuth("", smtpConfig.User, smtpConfig.Password, smtpConfig.Host)
	}

	// 发送邮件 - 使用实际发件人地址
	addr := fmt.Sprintf("%s:%d", smtpConfig.Host, smtpConfig.Port)

	if smtpConfig.TLS {
		// 对于465端口，使用SSL直接连接
		if smtpConfig.Port == 465 {
			return c.sendWithSSL(addr, auth, actualFrom, []string{to}, message, smtpConfig)
		} else {
			// 对于587端口，使用STARTTLS
			return c.sendWithTLSConfig(addr, auth, actualFrom, []string{to}, message, smtpConfig)
		}
	} else {
		return smtp.SendMail(addr, auth, actualFrom, []string{to}, message)
	}
}

// sendWithTLS 使用TLS发送邮件
func (c *OutboundClient) sendWithTLS(addr string, auth smtp.Auth, from string, to []string, msg []byte) error {
	// 连接到SMTP服务器
	client, err := smtp.Dial(addr)
	if err != nil {
		return fmt.Errorf("连接SMTP服务器失败: %v", err)
	}
	defer client.Close()

	// 启动TLS
	tlsConfig := &tls.Config{
		ServerName: c.config.OutboundSMTPHost,
	}

	if err = client.StartTLS(tlsConfig); err != nil {
		return fmt.Errorf("启动TLS失败: %v", err)
	}

	// 认证（如果提供了认证信息）
	if auth != nil {
		if err = client.Auth(auth); err != nil {
			return fmt.Errorf("SMTP认证失败: %v", err)
		}
	}

	// 设置发件人
	if err = client.Mail(from); err != nil {
		return fmt.Errorf("设置发件人失败: %v", err)
	}

	// 设置收件人
	for _, addr := range to {
		if err = client.Rcpt(addr); err != nil {
			return fmt.Errorf("设置收件人失败: %v", err)
		}
	}

	// 发送邮件内容
	w, err := client.Data()
	if err != nil {
		return fmt.Errorf("获取数据写入器失败: %v", err)
	}

	_, err = w.Write(msg)
	if err != nil {
		return fmt.Errorf("写入邮件内容失败: %v", err)
	}

	err = w.Close()
	if err != nil {
		return fmt.Errorf("关闭数据写入器失败: %v", err)
	}

	return client.Quit()
}

// sendWithTLSConfig 使用指定的SMTP配置和TLS发送邮件
func (c *OutboundClient) sendWithTLSConfig(addr string, auth smtp.Auth, from string, to []string, msg []byte, smtpConfig *config.SMTPConfig) error {
	// 连接到SMTP服务器
	client, err := smtp.Dial(addr)
	if err != nil {
		return fmt.Errorf("连接SMTP服务器失败: %v", err)
	}
	defer client.Close()

	// 启动TLS
	tlsConfig := &tls.Config{
		ServerName: smtpConfig.Host,
	}

	if err = client.StartTLS(tlsConfig); err != nil {
		return fmt.Errorf("启动TLS失败: %v", err)
	}

	// 认证（如果提供了认证信息）
	if auth != nil {
		if err = client.Auth(auth); err != nil {
			return fmt.Errorf("SMTP认证失败: %v", err)
		}
	}

	// 设置发件人
	if err = client.Mail(from); err != nil {
		return fmt.Errorf("设置发件人失败: %v", err)
	}

	// 设置收件人
	for _, addr := range to {
		if err = client.Rcpt(addr); err != nil {
			return fmt.Errorf("设置收件人失败: %v", err)
		}
	}

	// 发送邮件内容
	w, err := client.Data()
	if err != nil {
		return fmt.Errorf("开始发送邮件内容失败: %v", err)
	}

	_, err = w.Write(msg)
	if err != nil {
		return fmt.Errorf("写入邮件内容失败: %v", err)
	}

	err = w.Close()
	if err != nil {
		return fmt.Errorf("关闭数据写入器失败: %v", err)
	}

	return client.Quit()
}

// sendWithSSL 使用SSL直接连接发送邮件（适用于465端口）
func (c *OutboundClient) sendWithSSL(addr string, auth smtp.Auth, from string, to []string, msg []byte, smtpConfig *config.SMTPConfig) error {
	// 创建TLS配置
	tlsConfig := &tls.Config{
		ServerName: smtpConfig.Host,
	}

	// 直接使用TLS连接
	conn, err := tls.Dial("tcp", addr, tlsConfig)
	if err != nil {
		return fmt.Errorf("SSL连接失败: %v", err)
	}
	defer conn.Close()

	// 创建SMTP客户端
	client, err := smtp.NewClient(conn, smtpConfig.Host)
	if err != nil {
		return fmt.Errorf("创建SMTP客户端失败: %v", err)
	}
	defer client.Close()

	// 认证（如果提供了认证信息）
	if auth != nil {
		if err = client.Auth(auth); err != nil {
			return fmt.Errorf("SMTP认证失败: %v", err)
		}
	}

	// 设置发件人
	if err = client.Mail(from); err != nil {
		return fmt.Errorf("设置发件人失败: %v", err)
	}

	// 设置收件人
	for _, addr := range to {
		if err = client.Rcpt(addr); err != nil {
			return fmt.Errorf("设置收件人失败: %v", err)
		}
	}

	// 发送邮件内容
	w, err := client.Data()
	if err != nil {
		return fmt.Errorf("开始发送邮件内容失败: %v", err)
	}

	_, err = w.Write(msg)
	if err != nil {
		return fmt.Errorf("写入邮件内容失败: %v", err)
	}

	err = w.Close()
	if err != nil {
		return fmt.Errorf("关闭数据写入器失败: %v", err)
	}

	return client.Quit()
}

// buildMessage 构建邮件消息
func (c *OutboundClient) buildMessage(from, to, subject, body string, originalFrom ...string) []byte {
	// 构建邮件头
	headers := make(map[string]string)
	headers["From"] = from
	headers["To"] = to

	// 如果提供了原始发件人，设置Reply-To
	if len(originalFrom) > 0 && originalFrom[0] != from {
		headers["Reply-To"] = originalFrom[0]
	}

	// 对主题进行MIME编码（如果包含非ASCII字符）
	if needsMIMEEncoding(subject) {
		headers["Subject"] = encodeMIMEHeader(subject)
	} else {
		headers["Subject"] = subject
	}

	headers["MIME-Version"] = "1.0"
	headers["Content-Type"] = "text/plain; charset=UTF-8"

	// 对邮件正文进行编码处理
	var encodedBody string
	var transferEncoding string

	if needsMIMEEncoding(body) {
		// 使用Base64编码处理包含中文的内容
		encodedBody = base64.StdEncoding.EncodeToString([]byte(body))
		transferEncoding = "base64"

		// 将Base64编码的内容按76字符换行（RFC标准）
		var formattedBody strings.Builder
		for i := 0; i < len(encodedBody); i += 76 {
			end := i + 76
			if end > len(encodedBody) {
				end = len(encodedBody)
			}
			formattedBody.WriteString(encodedBody[i:end])
			if end < len(encodedBody) {
				formattedBody.WriteString("\r\n")
			}
		}
		encodedBody = formattedBody.String()
	} else {
		// 纯ASCII内容，直接使用
		encodedBody = body
		transferEncoding = "7bit"
	}

	headers["Content-Transfer-Encoding"] = transferEncoding

	// 添加自定义头部标识
	headers["X-Mailer"] = "NBEmail System"

	// 构建完整消息
	var message strings.Builder
	for k, v := range headers {
		message.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}
	message.WriteString("\r\n")
	message.WriteString(encodedBody)

	return []byte(message.String())
}

// IsExternalEmail 检查是否为外部邮箱
func (c *OutboundClient) IsExternalEmail(email string) bool {
	if !strings.Contains(email, "@") {
		return false
	}
	
	domain := strings.Split(email, "@")[1]
	return domain != c.config.Domain && domain != "localhost"
}

// LogSendAttempt 记录发送尝试
func (c *OutboundClient) LogSendAttempt(from, to, subject string, err error) {
	if err != nil {
		log.Printf("外部邮件发送失败 - From: %s, To: %s, Subject: %s, Error: %v", from, to, subject, err)
	} else {
		log.Printf("外部邮件发送成功 - From: %s, To: %s, Subject: %s", from, to, subject)
	}
}

// needsMIMEEncoding 检查字符串是否需要MIME编码
func needsMIMEEncoding(s string) bool {
	for _, r := range s {
		if r > 127 {
			return true
		}
	}
	return false
}

// encodeMIMEHeader 对邮件头部进行MIME编码
func encodeMIMEHeader(s string) string {
	if !needsMIMEEncoding(s) {
		return s
	}

	// 使用Base64编码
	encoded := base64.StdEncoding.EncodeToString([]byte(s))
	return fmt.Sprintf("=?UTF-8?B?%s?=", encoded)
}
